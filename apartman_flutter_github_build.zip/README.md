# Apartman Yönetimi APK Alma - Kurulum Gerektirmeyen Yol

Bu klasör, Flutter kurmadan GitHub üzerinden APK üretmeniz için hazırlandı.

## Ne yapacaksınız?

### 1. GitHub hesabı açın
GitHub hesabınız yoksa açın.

### 2. Yeni bir repo oluşturun
Örnek isim:
`apartman-yonetimi`

### 3. Bu ZIP içindeki dosyaları repoya yükleyin
Özellikle şunlar olmalı:
- `pubspec.yaml`
- `lib/main.dart`
- `.github/workflows/android-apk.yml`

### 4. GitHub'da Actions sekmesine girin
Repo açılınca üst menüde **Actions** sekmesi olur.

### 5. Workflow'u çalıştırın
Solda **Android APK Build** görünür.
Ona tıklayın.
Sonra **Run workflow** butonuna basın.

### 6. APK'yı indirin
İşlem bitince aşağıda **Artifacts** bölümünde
`apartman-yonetimi-apk`
çıkar.

Oradan APK dosyasını indirirsiniz.

---

## Önemli Not
Bu yöntemle:
- bilgisayara Flutter kurmanız gerekmez
- Android Studio kurmanız gerekmez
- sadece GitHub hesabı yeterlidir

---

## Sonraki Geliştirmeler
İsterseniz sonraki aşamada şunları da ekleyebiliriz:
- uygulama ikonu
- giriş şifresi
- gerçek veri kaydetme
- SQLite veritabanı
- PDF makbuz
- WhatsApp hatırlatma