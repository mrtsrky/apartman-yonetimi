import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const ApartmanYonetimiApp());
}

class ApartmanYonetimiApp extends StatelessWidget {
  const ApartmanYonetimiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Apartman Yönetimi',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        scaffoldBackgroundColor: const Color(0xfff5f7fb),
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final apartmanController = TextEditingController(text: 'Niyazi Sarı Apartmanı');
  final sifreController = TextEditingController(text: '1234');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xff111827), Color(0xff1f2937), Color(0xff374151)],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Card(
              elevation: 10,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              color: Colors.white.withValues(alpha: 0.10),
              child: Container(
                width: 420,
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: const Icon(Icons.apartment, color: Colors.white, size: 34),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Apartman Yönetimi',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Yönetici mobil paneli giriş ekranı',
                      style: TextStyle(color: Colors.white.withValues(alpha: 0.72)),
                    ),
                    const SizedBox(height: 24),
                    _buildLabel('Apartman Adı'),
                    const SizedBox(height: 8),
                    _buildTextField(apartmanController, false),
                    const SizedBox(height: 16),
                    _buildLabel('Şifre'),
                    const SizedBox(height: 8),
                    _buildTextField(sifreController, true),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: FilledButton.icon(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (_) => HomePage(apartmanAdi: apartmanController.text.trim()),
                            ),
                          );
                        },
                        icon: const Icon(Icons.login),
                        label: const Text('Giriş Yap'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Demo sürüm: giriş kontrolü örnek amaçlıdır.',
                      style: TextStyle(color: Colors.white.withValues(alpha: 0.55), fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    );
  }

  Widget _buildTextField(TextEditingController controller, bool obscure) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white.withValues(alpha: 0.10),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String apartmanAdi;

  const HomePage({super.key, required this.apartmanAdi});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedIndex = 0;
  String selectedMonth = 'Mart';
  bool notificationsOn = true;
  final searchController = TextEditingController();

  final List<String> months = const [
    'Ocak',
    'Şubat',
    'Mart',
    'Nisan',
    'Mayıs',
    'Haziran',
    'Temmuz',
    'Ağustos',
    'Eylül',
    'Ekim',
    'Kasım',
    'Aralık',
  ];

  final List<Resident> residents = [
    Resident(id: 1, daireNo: 1, adSoyad: 'Gönül Ölçer', telefon: '', odemeler: {'Mart': 600}),
    Resident(id: 2, daireNo: 2, adSoyad: 'Ali Tüysüz', telefon: '536 616 14 15', odemeler: {'Mart': 600}),
    Resident(id: 3, daireNo: 3, adSoyad: 'Ramazan Kartal', telefon: '542 727 91 56', odemeler: {'Mart': 600}),
    Resident(id: 4, daireNo: 4, adSoyad: 'Turgay Sarı', telefon: '532 645 40 98', odemeler: {'Şubat': 600, 'Mart': 600}),
    Resident(id: 5, daireNo: 5, adSoyad: 'Murat Sarıkaya', telefon: '505 809 95 11', odemeler: {}),
    Resident(id: 6, daireNo: 6, adSoyad: 'Kutlay Uslu', telefon: '555 706 50 71', odemeler: {'Mart': 600}),
    Resident(id: 7, daireNo: 7, adSoyad: 'Aytekin Çamkara', telefon: '536 683 54 12', odemeler: {'Mart': 600}),
    Resident(id: 8, daireNo: 8, adSoyad: 'Erkan Kaya', telefon: '', odemeler: {}),
  ];

  final List<TransactionItem> transactions = [
    TransactionItem(id: 1, tur: 'Gider', tarih: DateTime(2026, 1, 6), aciklama: 'Silikon ve hızlı yapıştırıcı', tutar: 200),
    TransactionItem(id: 2, tur: 'Gider', tarih: DateTime(2026, 1, 10), aciklama: 'Temizlikçi', tutar: 3500),
    TransactionItem(id: 3, tur: 'Gider', tarih: DateTime(2026, 1, 16), aciklama: 'Asansör bakım', tutar: 2200),
    TransactionItem(id: 4, tur: 'Gelir', tarih: DateTime(2026, 3, 1), aciklama: 'Mart aidat tahsilatı', tutar: 3600),
  ];

  static const int aidatTutar = 600;

  List<Resident> get filteredResidents {
    final q = searchController.text.trim().toLowerCase();
    if (q.isEmpty) return [...residents]..sort((a, b) => a.daireNo.compareTo(b.daireNo));
    return residents
        .where((r) =>
            r.adSoyad.toLowerCase().contains(q) ||
            r.daireNo.toString().contains(q) ||
            r.telefon.contains(q))
        .toList()
      ..sort((a, b) => a.daireNo.compareTo(b.daireNo));
  }

  int get totalIncome => transactions.where((t) => t.tur == 'Gelir').fold(0, (a, b) => a + b.tutar);
  int get totalExpense => transactions.where((t) => t.tur == 'Gider').fold(0, (a, b) => a + b.tutar);
  int get cashBalance => totalIncome - totalExpense;
  int get monthlyCollected => residents.fold(0, (sum, r) => sum + (r.odemeler[selectedMonth] ?? 0));
  int get monthlyExpected => residents.length * aidatTutar;
  int get paidCount => residents.where((r) => (r.odemeler[selectedMonth] ?? 0) > 0).length;
  int get unpaidCount => residents.length - paidCount;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildSummaryPage(),
      _buildAidatPage(),
      _buildKasaPage(),
      _buildResidentsPage(),
      _buildSettingsPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Apartman Yönetimi', style: TextStyle(fontWeight: FontWeight.w700)),
            Text(widget.apartmanAdi, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400)),
          ],
        ),
        actions: [
          IconButton(
            onPressed: _exportJson,
            icon: const Icon(Icons.download_rounded),
            tooltip: 'JSON dışa aktar',
          )
        ],
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (value) => setState(() => selectedIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Özet'),
          NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Aidat'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Kasa'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Daireler'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Ayarlar'),
        ],
      ),
      floatingActionButton: selectedIndex == 2
          ? FloatingActionButton.extended(
              onPressed: _showAddTransactionDialog,
              icon: const Icon(Icons.add),
              label: const Text('Kayıt Ekle'),
            )
          : selectedIndex == 3
              ? FloatingActionButton.extended(
                  onPressed: _showAddResidentDialog,
                  icon: const Icon(Icons.person_add),
                  label: const Text('Sakin Ekle'),
                )
              : null,
    );
  }

  Widget _buildSummaryPage() {
    final unpaidResidents = filteredResidents.where((r) => (r.odemeler[selectedMonth] ?? 0) == 0).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSearchBox(),
        const SizedBox(height: 14),
        GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.25,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _statCard('Toplam Gelir', tl(totalIncome), Icons.trending_up),
            _statCard('Toplam Gider', tl(totalExpense), Icons.trending_down),
            _statCard('Kasa Durumu', tl(cashBalance), Icons.account_balance_wallet),
            _statCard('Toplam Daire', residents.length.toString(), Icons.home_work),
          ],
        ),
        const SizedBox(height: 16),
        _sectionCard(
          title: 'Aylık Aidat Özeti',
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                value: selectedMonth,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(18))),
                ),
                items: months
                    .map((m) => DropdownMenuItem<String>(value: m, child: Text(m)))
                    .toList(),
                onChanged: (value) {
                  if (value != null) setState(() => selectedMonth = value);
                },
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: _miniInfo('Tahsil Edilen', tl(monthlyCollected))),
                  const SizedBox(width: 10),
                  Expanded(child: _miniInfo('Beklenen', tl(monthlyExpected))),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _miniInfo('Ödeyen', paidCount.toString())),
                  const SizedBox(width: 10),
                  Expanded(child: _miniInfo('Ödemeyen', unpaidCount.toString())),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _sectionCard(
          title: 'Bu Ay Ödemeyenler',
          child: unpaidResidents.isEmpty
              ? Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.check_circle, color: Colors.green),
                      SizedBox(width: 8),
                      Expanded(child: Text('Seçili ay için tüm ödemeler tamamlandı.')),
                    ],
                  ),
                )
              : Column(
                  children: unpaidResidents.take(6).map((r) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        tileColor: Colors.grey.shade50,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        title: Text('Daire ${r.daireNo} • ${r.adSoyad}'),
                        subtitle: Text('Borç: ${tl(r.borc(months, aidatTutar))}'),
                        trailing: const Chip(label: Text('Bekliyor')),
                      ),
                    );
                  }).toList(),
                ),
        ),
      ],
    );
  }

  Widget _buildAidatPage() {
    final list = filteredResidents;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(child: _buildSearchBox()),
            const SizedBox(width: 10),
            SizedBox(
              width: 132,
              child: DropdownButtonFormField<String>(
                value: selectedMonth,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(18))),
                ),
                items: months.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                onChanged: (value) {
                  if (value != null) setState(() => selectedMonth = value);
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        ...list.map((r) {
          final paid = (r.odemeler[selectedMonth] ?? 0) > 0;
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Daire ${r.daireNo} • ${r.adSoyad}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 4),
                              Text('Telefon: ${r.telefon.isEmpty ? 'Kayıt yok' : r.telefon}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                              const SizedBox(height: 4),
                              Text('Toplam borç: ${tl(r.borc(months, aidatTutar))}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                            ],
                          ),
                        ),
                        Chip(
                          backgroundColor: paid ? Colors.green.shade50 : Colors.red.shade50,
                          label: Text(
                            paid ? 'Ödendi' : 'Ödenmedi',
                            style: TextStyle(color: paid ? Colors.green.shade700 : Colors.red.shade700),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: () => _showTahsilatDialog(r),
                            child: const Text('Tahsil Et'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              setState(() {
                                r.odemeler.remove(selectedMonth);
                              });
                            },
                            child: const Text('Ödemeyi Kaldır'),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildKasaPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(child: _statCard('Gelir Toplamı', tl(totalIncome), Icons.trending_up)),
            const SizedBox(width: 12),
            Expanded(child: _statCard('Gider Toplamı', tl(totalExpense), Icons.trending_down)),
          ],
        ),
        const SizedBox(height: 16),
        _sectionCard(
          title: 'İşlem Listesi',
          child: Column(
            children: transactions.map((t) {
              final isGelir = t.tur == 'Gelir';
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  tileColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  title: Text(t.aciklama, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(formatDate(t.tarih)),
                  trailing: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Chip(
                        label: Text(t.tur),
                        backgroundColor: isGelir ? Colors.green.shade50 : Colors.amber.shade50,
                      ),
                      const SizedBox(height: 2),
                      Text(tl(t.tutar), style: const TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildResidentsPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSearchBox(),
        const SizedBox(height: 14),
        ...filteredResidents.map((r) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Daire ${r.daireNo} • ${r.adSoyad}', style: const TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text(r.telefon.isEmpty ? 'Telefon bilgisi yok' : r.telefon),
                          const SizedBox(height: 4),
                          Text('Borç: ${tl(r.borc(months, aidatTutar))}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        if (r.telefon.isNotEmpty)
                          IconButton.filledTonal(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('${r.telefon} aranacak şekilde entegre edilebilir.')),
                              );
                            },
                            icon: const Icon(Icons.call),
                          ),
                        const SizedBox(height: 6),
                        IconButton.filledTonal(
                          onPressed: () {
                            setState(() {
                              residents.removeWhere((item) => item.id == r.id);
                            });
                          },
                          icon: const Icon(Icons.delete_outline),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildSettingsPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionCard(
          title: 'Bildirim ve Sistem',
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.notifications_active_outlined),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Aidat hatırlatma bildirimi', style: TextStyle(fontWeight: FontWeight.w600)),
                          SizedBox(height: 2),
                          Text('Ay başı sakinlere bildirim göndermek için örnek ayar', style: TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                    Switch(
                      value: notificationsOn,
                      onChanged: (value) => setState(() => notificationsOn = value),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.orange),
                    SizedBox(width: 8),
                    Expanded(child: Text('Bu sürüm temel Flutter demo altyapısıdır. İstenirse veritabanı ve giriş sistemi eklenebilir.')),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                      (_) => false,
                    );
                  },
                  icon: const Icon(Icons.logout),
                  label: const Text('Oturumu Kapat'),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBox() {
    return TextField(
      controller: searchController,
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: 'Daire no, isim veya telefon ara',
        prefixIcon: const Icon(Icons.search),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _statCard(String title, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [BoxShadow(color: Color(0x11000000), blurRadius: 12, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: Text(title, style: const TextStyle(fontSize: 13, color: Colors.black54))),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                child: Icon(icon, size: 20),
              )
            ],
          ),
          const SizedBox(height: 12),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget _miniInfo(String title, String value) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
        ],
      ),
    );
  }

  Widget _sectionCard({required String title, required Widget child}) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }

  void _showTahsilatDialog(Resident resident) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Aidat Tahsilatı', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Text('Daire ${resident.daireNo} • ${resident.adSoyad} • $selectedMonth'),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      setState(() {
                        resident.odemeler[selectedMonth] = aidatTutar;
                        transactions.insert(
                          0,
                          TransactionItem(
                            id: DateTime.now().millisecondsSinceEpoch,
                            tur: 'Gelir',
                            tarih: DateTime.now(),
                            aciklama: 'Daire ${resident.daireNo} $selectedMonth aidat tahsilatı',
                            tutar: aidatTutar,
                          ),
                        );
                      });
                      Navigator.pop(context);
                    },
                    child: Text('${tl(aidatTutar)} Tahsil Et'),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() {
                        resident.odemeler[selectedMonth] = aidatTutar ~/ 2;
                        transactions.insert(
                          0,
                          TransactionItem(
                            id: DateTime.now().millisecondsSinceEpoch + 1,
                            tur: 'Gelir',
                            tarih: DateTime.now(),
                            aciklama: 'Daire ${resident.daireNo} $selectedMonth kısmi aidat tahsilatı',
                            tutar: aidatTutar ~/ 2,
                          ),
                        );
                      });
                      Navigator.pop(context);
                    },
                    child: Text('${tl(aidatTutar ~/ 2)} Kısmi Tahsil Et'),
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }

  void _showAddTransactionDialog() {
    final aciklamaController = TextEditingController();
    final tutarController = TextEditingController();
    String tur = 'Gelir';
    DateTime secilenTarih = DateTime.now();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Kasa Kaydı Ekle'),
          content: StatefulBuilder(
            builder: (context, setLocal) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: tur,
                      items: const [
                        DropdownMenuItem(value: 'Gelir', child: Text('Gelir')),
                        DropdownMenuItem(value: 'Gider', child: Text('Gider')),
                      ],
                      onChanged: (value) {
                        if (value != null) setLocal(() => tur = value);
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: aciklamaController,
                      decoration: const InputDecoration(labelText: 'Açıklama'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: tutarController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Tutar'),
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Tarih'),
                      subtitle: Text(formatDate(secilenTarih)),
                      trailing: IconButton(
                        onPressed: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: secilenTarih,
                            firstDate: DateTime(2024),
                            lastDate: DateTime(2030),
                          );
                          if (picked != null) setLocal(() => secilenTarih = picked);
                        },
                        icon: const Icon(Icons.calendar_month),
                      ),
                    )
                  ],
                ),
              );
            },
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
            FilledButton(
              onPressed: () {
                final tutar = int.tryParse(tutarController.text.trim());
                if (aciklamaController.text.trim().isEmpty || tutar == null) return;
                setState(() {
                  transactions.insert(
                    0,
                    TransactionItem(
                      id: DateTime.now().millisecondsSinceEpoch,
                      tur: tur,
                      tarih: secilenTarih,
                      aciklama: aciklamaController.text.trim(),
                      tutar: tutar,
                    ),
                  );
                });
                Navigator.pop(context);
              },
              child: const Text('Kaydet'),
            ),
          ],
        );
      },
    );
  }

  void _showAddResidentDialog() {
    final daireController = TextEditingController();
    final adController = TextEditingController();
    final telefonController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Yeni Daire Sakini'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: daireController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Daire No'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: adController,
                  decoration: const InputDecoration(labelText: 'Ad Soyad'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: telefonController,
                  decoration: const InputDecoration(labelText: 'Telefon'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
            FilledButton(
              onPressed: () {
                final daireNo = int.tryParse(daireController.text.trim());
                if (daireNo == null || adController.text.trim().isEmpty) return;
                setState(() {
                  residents.add(
                    Resident(
                      id: DateTime.now().millisecondsSinceEpoch,
                      daireNo: daireNo,
                      adSoyad: adController.text.trim(),
                      telefon: telefonController.text.trim(),
                      odemeler: {},
                    ),
                  );
                });
                Navigator.pop(context);
              },
              child: const Text('Kaydet'),
            ),
          ],
        );
      },
    );
  }

  void _exportJson() {
    final map = {
      'apartmanAdi': widget.apartmanAdi,
      'selectedMonth': selectedMonth,
      'notificationsOn': notificationsOn,
      'residents': residents.map((e) => e.toJson()).toList(),
      'transactions': transactions.map((e) => e.toJson()).toList(),
    };

    final pretty = const JsonEncoder.withIndent('  ').convert(map);
    Clipboard.setData(ClipboardData(text: pretty));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('JSON veri panoya kopyalandı. Dosyaya dönüştürme eklenebilir.')),
    );
  }
}

class Resident {
  final int id;
  final int daireNo;
  final String adSoyad;
  final String telefon;
  final Map<String, int> odemeler;

  Resident({
    required this.id,
    required this.daireNo,
    required this.adSoyad,
    required this.telefon,
    required this.odemeler,
  });

  int borc(List<String> months, int aidatTutar) {
    final paid = months.fold<int>(0, (sum, month) => sum + (odemeler[month] ?? 0));
    return (months.length * aidatTutar) - paid;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'daireNo': daireNo,
        'adSoyad': adSoyad,
        'telefon': telefon,
        'odemeler': odemeler,
      };
}

class TransactionItem {
  final int id;
  final String tur;
  final DateTime tarih;
  final String aciklama;
  final int tutar;

  TransactionItem({
    required this.id,
    required this.tur,
    required this.tarih,
    required this.aciklama,
    required this.tutar,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'tur': tur,
        'tarih': tarih.toIso8601String(),
        'aciklama': aciklama,
        'tutar': tutar,
      };
}

String tl(int value) {
  return '$value ₺';
}

String formatDate(DateTime date) {
  final day = date.day.toString().padLeft(2, '0');
  final month = date.month.toString().padLeft(2, '0');
  final year = date.year.toString();
  return '$day.$month.$year';
}